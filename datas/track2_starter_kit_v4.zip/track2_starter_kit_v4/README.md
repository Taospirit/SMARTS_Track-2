## starter-kit 

The starter-kit includes multiple training examples, a submission example.

### Training Examples

We offer some training examples listed in the `starter_kit/train`.
- `keeplane.py`: muti-agent learning with LaneFollowing policy
- `multi_instance.py`: run multiple training and evaluation instance concurrently with Ray.
- `randompolicy.py`: random policy multi-agent learning with random policy
- `rllib_marl.py`: RLlib-based multi-agent learning, with PPO algorithm

### Submission Example

We offer a submission example locates in `stater_kit/submission`. To submit your solution, you must include the following
files in your submission:

- `agent.py`: you **must** implement this file in your submission, since our evaluation tool will import your agent model from this file. For the implementation, you must offer an `AgentSpec` instance named `agent_spec`. More details please read the example `starter_kit/submission/agent.py`.
- a checkpoint directory: the checkpoint directory includes your saved model.

**NOTE**: to submit your solution to our platform, you must compress it as a zip file.

### Run a training example:

To run a training example, you can execute any of the following to do.

```python
python keeplane.py --headless --scenario {scenaio_dir}
python multi_instance.py --headless --scenario {scenario_dir}
python randompolicy.py --headless --scenario {scenario_dir}
python rllib_marl.py --headless --scenario {scenario_dir}
```

### Quick Start
```bash
# install environment dependencies according to setup.md

# build scenarios
scl scenario build-all ../dataset_public

# open one tab to run envision, or using scl envision start -s dataset_public
supervisord

# run example
python keeplane.py --scenario xxx

# open localhost:8081 to see render
# open localhost:8082 to see SMARTS docs to get to know more details
scl docs
```

Enjoy it !